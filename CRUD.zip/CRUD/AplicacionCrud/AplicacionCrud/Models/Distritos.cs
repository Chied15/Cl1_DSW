﻿using System;
using System.Collections.Generic;

namespace AplicacionCrud.Models
{
    public partial class Distritos
    {
        public Distritos()
        {
            Empleados = new HashSet<Empleados>();
        }

        public int IdDistrito { get; set; }
        public string NomDistrito { get; set; }

        public virtual ICollection<Empleados> Empleados { get; set; }
    }
}
