﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AplicacionCrud.Models
{
    public partial class Negocios2020_02Context : DbContext
    {
        public Negocios2020_02Context()
        {
        }

        public Negocios2020_02Context(DbContextOptions<Negocios2020_02Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Cargos> Cargos { get; set; }
        public virtual DbSet<Categorias> Categorias { get; set; }
        public virtual DbSet<Clientes> Clientes { get; set; }
        public virtual DbSet<Distritos> Distritos { get; set; }
        public virtual DbSet<Empleados> Empleados { get; set; }
        public virtual DbSet<Paises> Paises { get; set; }
        public virtual DbSet<Pedidoscabe> Pedidoscabe { get; set; }
        
        public virtual DbSet<Productos> Productos { get; set; }
        public virtual DbSet<Proveedores> Proveedores { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=DESKTOP-EV0PJKR\\SQLEXPRESS;Database=Negocios2020_02;User Id=ra; Password=Ch082315");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Cargos>(entity =>
            {
                entity.HasKey(e => e.Idcargo)
                    .HasName("PK__Cargos__0515A5AD97746648");

                entity.ToTable("Cargos", "RRHH");

                entity.Property(e => e.Idcargo)
                    .HasColumnName("idcargo")
                    .ValueGeneratedNever();

                entity.Property(e => e.DesCargo)
                    .IsRequired()
                    .HasColumnName("desCargo")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Categorias>(entity =>
            {
                entity.HasKey(e => e.IdCategoria)
                    .HasName("PK__categori__A3C02A10F61ECF54");

                entity.ToTable("categorias", "Compras");

                entity.Property(e => e.IdCategoria).ValueGeneratedNever();

                entity.Property(e => e.Descripcion).HasColumnType("text");

                entity.Property(e => e.NombreCategoria)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Clientes>(entity =>
            {
                entity.HasKey(e => e.IdCliente)
                    .HasName("PK__clientes__D5946642F7CA8513");

                entity.ToTable("clientes", "Ventas");

                entity.Property(e => e.IdCliente)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.DirCliente)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.FonoCliente)
                    .IsRequired()
                    .HasColumnName("fonoCliente")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Idpais)
                    .HasColumnName("idpais")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.NomCliente)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdpaisNavigation)
                    .WithMany(p => p.Clientes)
                    .HasForeignKey(d => d.Idpais)
                    .HasConstraintName("FK__clientes__idpais__286302EC");
            });

            modelBuilder.Entity<Distritos>(entity =>
            {
                entity.HasKey(e => e.IdDistrito)
                    .HasName("PK__Distrito__494092A84783D187");

                entity.ToTable("Distritos", "RRHH");

                entity.Property(e => e.IdDistrito)
                    .HasColumnName("idDistrito")
                    .ValueGeneratedNever();

                entity.Property(e => e.NomDistrito)
                    .IsRequired()
                    .HasColumnName("nomDistrito")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Empleados>(entity =>
            {
                entity.HasKey(e => e.IdEmpleado)
                    .HasName("PK__empleado__CE6D8B9E2CB168FF");

                entity.ToTable("empleados", "RRHH");

                entity.Property(e => e.IdEmpleado).ValueGeneratedNever();

                entity.Property(e => e.ApeEmpleado)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DirEmpleado)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.FecContrata).HasColumnType("datetime");

                entity.Property(e => e.FecNac).HasColumnType("datetime");

                entity.Property(e => e.FonoEmpleado)
                    .HasColumnName("fonoEmpleado")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.IdCargo).HasColumnName("idCargo");

                entity.Property(e => e.IdDistrito).HasColumnName("idDistrito");

                entity.Property(e => e.NomEmpleado)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdCargoNavigation)
                    .WithMany(p => p.Empleados)
                    .HasForeignKey(d => d.IdCargo)
                    .HasConstraintName("FK__empleados__idCar__36B12243");

                entity.HasOne(d => d.IdDistritoNavigation)
                    .WithMany(p => p.Empleados)
                    .HasForeignKey(d => d.IdDistrito)
                    .HasConstraintName("FK__empleados__idDis__35BCFE0A");
            });

            modelBuilder.Entity<Paises>(entity =>
            {
                entity.HasKey(e => e.Idpais)
                    .HasName("PK__paises__AD357A25ADEB3FD6");

                entity.ToTable("paises", "Ventas");

                entity.Property(e => e.Idpais)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.NombrePais)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Pedidoscabe>(entity =>
            {
                entity.HasKey(e => e.IdPedido)
                    .HasName("PK__pedidosc__9D335DC31F8BADC8");

                entity.ToTable("pedidoscabe", "Ventas");

                entity.Property(e => e.IdPedido).ValueGeneratedNever();

                entity.Property(e => e.CiuDestinatario)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.DepDestinatario)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Destinatario)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.DirDestinatario)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.EnvioPedido)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength()
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.FechaEntrega).HasColumnType("datetime");

                entity.Property(e => e.FechaEnvio).HasColumnType("datetime");

                entity.Property(e => e.FechaPedido)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IdCliente)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.PaiDestinatario)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.RefDestnatario)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdClienteNavigation)
                    .WithMany(p => p.Pedidoscabe)
                    .HasForeignKey(d => d.IdCliente)
                    .HasConstraintName("FK__pedidosca__IdCli__398D8EEE");

                entity.HasOne(d => d.IdEmpleadoNavigation)
                    .WithMany(p => p.Pedidoscabe)
                    .HasForeignKey(d => d.IdEmpleado)
                    .HasConstraintName("FK__pedidosca__IdEmp__3A81B327");
            });

            

            modelBuilder.Entity<Productos>(entity =>
            {
                entity.HasKey(e => e.IdProducto)
                    .HasName("PK__producto__09889210D72C189F");

                entity.ToTable("productos", "Compras");

                entity.Property(e => e.IdProducto).ValueGeneratedNever();

                entity.Property(e => e.CantxUnidad)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NomProducto)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.PrecioUnidad).HasColumnType("decimal(10, 0)");

                entity.HasOne(d => d.IdCategoriaNavigation)
                    .WithMany(p => p.Productos)
                    .HasForeignKey(d => d.IdCategoria)
                    .HasConstraintName("FK__productos__IdCat__2F10007B");

                entity.HasOne(d => d.IdProveedorNavigation)
                    .WithMany(p => p.Productos)
                    .HasForeignKey(d => d.IdProveedor)
                    .HasConstraintName("FK__productos__IdPro__2E1BDC42");
            });

            modelBuilder.Entity<Proveedores>(entity =>
            {
                entity.HasKey(e => e.IdProveedor)
                    .HasName("PK__proveedo__E8B631AFFE4C69D9");

                entity.ToTable("proveedores", "Compras");

                entity.Property(e => e.IdProveedor).ValueGeneratedNever();

                entity.Property(e => e.CargoContacto)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DirProveedor)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.FaxProveedor)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.FonoProveedor)
                    .IsRequired()
                    .HasColumnName("fonoProveedor")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Idpais)
                    .HasColumnName("idpais")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.NomContacto)
                    .IsRequired()
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.NomProveedor)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdpaisNavigation)
                    .WithMany(p => p.Proveedores)
                    .HasForeignKey(d => d.Idpais)
                    .HasConstraintName("FK__proveedor__idpai__2B3F6F97");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
