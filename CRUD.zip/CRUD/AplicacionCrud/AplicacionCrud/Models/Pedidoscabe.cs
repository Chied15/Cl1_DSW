﻿using System;
using System.Collections.Generic;

namespace AplicacionCrud.Models
{
    public partial class Pedidoscabe
    {
       

        public int IdPedido { get; set; }
        public string IdCliente { get; set; }
        public int? IdEmpleado { get; set; }
        public DateTime FechaPedido { get; set; }
        public DateTime? FechaEntrega { get; set; }
        public DateTime? FechaEnvio { get; set; }
        public string EnvioPedido { get; set; }
        public int? CantidaPedido { get; set; }
        public string Destinatario { get; set; }
        public string DirDestinatario { get; set; }
        public string CiuDestinatario { get; set; }
        public string RefDestnatario { get; set; }
        public string DepDestinatario { get; set; }
        public string PaiDestinatario { get; set; }

        public virtual Clientes IdClienteNavigation { get; set; }
        public virtual Empleados IdEmpleadoNavigation { get; set; }
       
    }
}
