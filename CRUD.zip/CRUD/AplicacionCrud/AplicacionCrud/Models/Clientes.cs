﻿using System;
using System.Collections.Generic;

namespace AplicacionCrud.Models
{
    public partial class Clientes
    {
        public Clientes()
        {
            Pedidoscabe = new HashSet<Pedidoscabe>();
        }

        public string IdCliente { get; set; }
        public string NomCliente { get; set; }
        public string DirCliente { get; set; }
        public string Idpais { get; set; }
        public string FonoCliente { get; set; }

        public virtual Paises IdpaisNavigation { get; set; }
        public virtual ICollection<Pedidoscabe> Pedidoscabe { get; set; }
    }
}
