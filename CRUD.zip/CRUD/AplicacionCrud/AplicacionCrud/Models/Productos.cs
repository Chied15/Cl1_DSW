﻿using System;
using System.Collections.Generic;

namespace AplicacionCrud.Models
{
    public partial class Productos
    {
      
        public int IdProducto { get; set; }
        public string NomProducto { get; set; }
        public int? IdProveedor { get; set; }
        public int? IdCategoria { get; set; }
        public string CantxUnidad { get; set; }
        public decimal PrecioUnidad { get; set; }
        public short UnidadesEnExistencia { get; set; }
        public short UnidadesEnPedido { get; set; }

        public virtual Categorias IdCategoriaNavigation { get; set; }
        public virtual Proveedores IdProveedorNavigation { get; set; }
     
    }
}
