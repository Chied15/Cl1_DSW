﻿using System;
using System.Collections.Generic;

namespace AplicacionCrud.Models
{
    public partial class Cargos
    {
        public Cargos()
        {
            Empleados = new HashSet<Empleados>();
        }

        public int Idcargo { get; set; }
        public string DesCargo { get; set; }

        public virtual ICollection<Empleados> Empleados { get; set; }
    }
}
