﻿using System;
using System.Collections.Generic;

namespace AplicacionCrud.Models
{
    public partial class Proveedores
    {
        public Proveedores()
        {
            Productos = new HashSet<Productos>();
        }

        public int IdProveedor { get; set; }
        public string NomProveedor { get; set; }
        public string DirProveedor { get; set; }
        public string NomContacto { get; set; }
        public string CargoContacto { get; set; }
        public string Idpais { get; set; }
        public string FonoProveedor { get; set; }
        public string FaxProveedor { get; set; }

        public virtual Paises IdpaisNavigation { get; set; }
        public virtual ICollection<Productos> Productos { get; set; }
    }
}
