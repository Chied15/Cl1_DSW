﻿using System;
using System.Collections.Generic;

namespace AplicacionCrud.Models
{
    public partial class Paises
    {
        public Paises()
        {
            Clientes = new HashSet<Clientes>();
            Proveedores = new HashSet<Proveedores>();
        }

        public string Idpais { get; set; }
        public string NombrePais { get; set; }

        public virtual ICollection<Clientes> Clientes { get; set; }
        public virtual ICollection<Proveedores> Proveedores { get; set; }
    }
}
