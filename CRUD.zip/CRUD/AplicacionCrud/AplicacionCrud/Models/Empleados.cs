﻿using System;
using System.Collections.Generic;

namespace AplicacionCrud.Models
{
    public partial class Empleados
    {
        public Empleados()
        {
            Pedidoscabe = new HashSet<Pedidoscabe>();
        }

        public int IdEmpleado { get; set; }
        public string ApeEmpleado { get; set; }
        public string NomEmpleado { get; set; }
        public DateTime FecNac { get; set; }
        public string DirEmpleado { get; set; }
        public int? IdDistrito { get; set; }
        public string FonoEmpleado { get; set; }
        public int? IdCargo { get; set; }
        public DateTime FecContrata { get; set; }

        public virtual Cargos IdCargoNavigation { get; set; }
        public virtual Distritos IdDistritoNavigation { get; set; }
        public virtual ICollection<Pedidoscabe> Pedidoscabe { get; set; }
    }
}
